self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8ab1c0f1d469c7cb2a50cf89afae816d",
    "url": "/podcastminiapp2/index.html"
  },
  {
    "revision": "0b75689d3a89567e8724",
    "url": "/podcastminiapp2/static/css/2.2cfa1b23.chunk.css"
  },
  {
    "revision": "fff04eb31e1d10b82b90",
    "url": "/podcastminiapp2/static/css/main.0ff82123.chunk.css"
  },
  {
    "revision": "0b75689d3a89567e8724",
    "url": "/podcastminiapp2/static/js/2.61bcb084.chunk.js"
  },
  {
    "revision": "7326c672501bfd008b3264e314f470c5",
    "url": "/podcastminiapp2/static/js/2.61bcb084.chunk.js.LICENSE"
  },
  {
    "revision": "fff04eb31e1d10b82b90",
    "url": "/podcastminiapp2/static/js/main.84a474da.chunk.js"
  },
  {
    "revision": "ef3ac1e971a1bc6bfb73",
    "url": "/podcastminiapp2/static/js/runtime-main.7f6034c3.js"
  },
  {
    "revision": "368636f1b6e330a4806185cdf6bb44bc",
    "url": "/podcastminiapp2/static/media/SFProDisplay-Bold.368636f1.ttf"
  },
  {
    "revision": "c5a8e1f150a5b6d6d37e0f95220ed5f6",
    "url": "/podcastminiapp2/static/media/SFProDisplay-Medium.c5a8e1f1.ttf"
  },
  {
    "revision": "6987bcc482500f459516dc0342836ee5",
    "url": "/podcastminiapp2/static/media/SFProDisplay-Regular.6987bcc4.ttf"
  },
  {
    "revision": "0538ddc92082d2ef2e7b375519825dac",
    "url": "/podcastminiapp2/static/media/SFProDisplay-Semibold.0538ddc9.ttf"
  },
  {
    "revision": "2b9e38f70ebf7414a2d36edbc27d5fc6",
    "url": "/podcastminiapp2/static/media/add_circle_24.2b9e38f7.svg"
  },
  {
    "revision": "72514932cf47a1fdfbc06512e5b83971",
    "url": "/podcastminiapp2/static/media/arrow_navbar.72514932.svg"
  },
  {
    "revision": "e26f3fb8bb29e618284d9a933a56c2b3",
    "url": "/podcastminiapp2/static/media/arrow_right.e26f3fb8.svg"
  },
  {
    "revision": "b16827a47adbaf1d94a2261ba1cd7611",
    "url": "/podcastminiapp2/static/media/avatar.b16827a4.png"
  },
  {
    "revision": "42e834477cd6372f01c59050419632ad",
    "url": "/podcastminiapp2/static/media/back.42e83447.svg"
  },
  {
    "revision": "7297716ab3dcce95c89eedcad2eb59cf",
    "url": "/podcastminiapp2/static/media/check_circle_outline_56.7297716a.svg"
  },
  {
    "revision": "e0faa4e800b9e29299509096a5e2a584",
    "url": "/podcastminiapp2/static/media/close_navbar.e0faa4e8.svg"
  },
  {
    "revision": "0ec788640db020a7892c130d885c220a",
    "url": "/podcastminiapp2/static/media/cut_gray.0ec78864.svg"
  },
  {
    "revision": "4287e3e6032c5531af13b025926e9ffc",
    "url": "/podcastminiapp2/static/media/frederik_chopin.4287e3e6.mp3"
  },
  {
    "revision": "e7d4378b6542b26da563b534968dfb38",
    "url": "/podcastminiapp2/static/media/ic_comment_outline.e7d4378b.svg"
  },
  {
    "revision": "4d471d02e62dc4a0d48a9b5147effa87",
    "url": "/podcastminiapp2/static/media/ic_eye.4d471d02.svg"
  },
  {
    "revision": "484d39816c14c32921b3b9ad546c099a",
    "url": "/podcastminiapp2/static/media/ic_like.484d3981.svg"
  },
  {
    "revision": "fc056f8a37f0bdfbed5c3c6d4f53c4c6",
    "url": "/podcastminiapp2/static/media/ic_reposts.fc056f8a.svg"
  },
  {
    "revision": "31872b82572051c06e7e701f61a7585d",
    "url": "/podcastminiapp2/static/media/lineage.31872b82.mp3"
  },
  {
    "revision": "e88280461f2e58791f56ae0ddfdedade",
    "url": "/podcastminiapp2/static/media/more.e8828046.svg"
  },
  {
    "revision": "c9af6b337e87963903bd3b175c8ab85b",
    "url": "/podcastminiapp2/static/media/more_blue_16.c9af6b33.svg"
  },
  {
    "revision": "4006f48fda09666d8b9a4dded14a29cf",
    "url": "/podcastminiapp2/static/media/music_blue.4006f48f.svg"
  },
  {
    "revision": "cf3855b0524d6a5314b07d3faf3ca725",
    "url": "/podcastminiapp2/static/media/music_gray.cf3855b0.svg"
  },
  {
    "revision": "65b112acfa9e1c5c2f357f0b5045cbac",
    "url": "/podcastminiapp2/static/media/pause_gray.65b112ac.svg"
  },
  {
    "revision": "52d6d4666e52a5d86a6a955699b60d08",
    "url": "/podcastminiapp2/static/media/pickture.52d6d466.svg"
  },
  {
    "revision": "0f196607cd0cb7fb9db748a5b4b3f14c",
    "url": "/podcastminiapp2/static/media/play_blue.0f196607.svg"
  },
  {
    "revision": "a30cf4cf812ea05fe155b4156ad53562",
    "url": "/podcastminiapp2/static/media/play_btn_podcast.a30cf4cf.svg"
  },
  {
    "revision": "d8aa19d46307f38c4803e3a47f09296a",
    "url": "/podcastminiapp2/static/media/plus.d8aa19d4.svg"
  },
  {
    "revision": "b4a48b0a434b1d7b5043850bdc9377c6",
    "url": "/podcastminiapp2/static/media/plus_48.b4a48b0a.svg"
  },
  {
    "revision": "d20009cbdddf26cb0b63d708adec35e2",
    "url": "/podcastminiapp2/static/media/podcast_icon.d20009cb.svg"
  },
  {
    "revision": "f8a82422b3f7437ab38f3754d584345d",
    "url": "/podcastminiapp2/static/media/remove_circle_24.f8a82422.svg"
  },
  {
    "revision": "2687e47f3f43cda071d5093f9639683b",
    "url": "/podcastminiapp2/static/media/search.2687e47f.svg"
  },
  {
    "revision": "921e67ff1580229b7b409083e11206a9",
    "url": "/podcastminiapp2/static/media/send.921e67ff.svg"
  },
  {
    "revision": "a847d9dbabcdc1246a06c578ede44dbb",
    "url": "/podcastminiapp2/static/media/standart_album.a847d9db.png"
  },
  {
    "revision": "8cd24b30fed4be1ac6673e07cc579b64",
    "url": "/podcastminiapp2/static/media/undo_gray.8cd24b30.svg"
  },
  {
    "revision": "5cdf4be252a5141fcf6b958091c48342",
    "url": "/podcastminiapp2/static/media/volume_down_blue.5cdf4be2.svg"
  },
  {
    "revision": "1ed9d62bae867c9f0b2e35588f6971df",
    "url": "/podcastminiapp2/static/media/volume_down_gray.1ed9d62b.svg"
  },
  {
    "revision": "a7459b2b265c74fdffdbaf70c718825d",
    "url": "/podcastminiapp2/static/media/volume_grow_blue.a7459b2b.svg"
  },
  {
    "revision": "25de7279d4af98db2025128694eaacc9",
    "url": "/podcastminiapp2/static/media/volume_grow_gray.25de7279.svg"
  }
]);